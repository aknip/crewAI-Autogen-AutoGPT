import Head from 'next/head'
import { SignedIn, SignedOut } from '@clerk/nextjs'
import { withServerSideAuth } from '@clerk/nextjs/ssr'
import React from 'react'
import Link from 'next/link'
import { CallToAction } from '@/components/CallToAction'
import { Header } from '@/components/Header'
import { Hero } from '@/components/Hero'
import { PrimaryFeatures } from '@/components/PrimaryFeatures'

export const getServerSideProps = withServerSideAuth()

export default function Home() {
  return (
    <>
      <Head>
        <title>Cosmo AI Assistant - Automating email processing for insurance agents</title>
        <meta name="description" content="Cosmo AI Assistant is an AI startup offering a SaaS product. It is an Outlook extension that helps to automate email processing, creating offer requests for insurance agents, and extracting risk data from customer requests." />
      </Head>
      <Header />
      <SignedIn>
        <p className="bg-red-400 p-8">You have successfully signed in</p>
      </SignedIn>
      <SignedOut>
        <p className="bg-red-400 p-8">
          Sign up for an account to get started
        </p>
      </SignedOut>
      <main>
        <Hero />
        <PrimaryFeatures />
        <CallToAction />
      </main>
    </>
  )
}