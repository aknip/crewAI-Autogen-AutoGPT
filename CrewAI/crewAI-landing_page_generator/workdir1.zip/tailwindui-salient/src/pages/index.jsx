import Head from 'next/head'
import { SignedIn, SignedOut } from '@clerk/nextjs'
import { withServerSideAuth } from '@clerk/nextjs/ssr'
import React from 'react'
import Link from 'next/link'
import { CallToAction } from '@/components/CallToAction'
import { Hero } from '@/components/Hero'
import { PrimaryFeatures } from '@/components/PrimaryFeatures'
import { SecondaryFeatures } from '@/components/SecondaryFeatures'

export const getServerSideProps = withServerSideAuth()

const SignupLink = () => (
  <Link href="/sign-up">
    <a className="">
      <img alt="Sign up" src="/icons/user-plus.svg" />
      <div>
        <h3>Sign up for an account</h3>
        <p>Sign up and sign in to explore all the features provided by Cosmo AI Assistant</p>
      </div>
      <div className="">
        <img src="/icons/arrow-right.svg" />
      </div>
    </a>
  </Link>
)

export default function Home() {
  return (
    <>
      <Head>
        <title>Cosmo AI Assistant - Automate your email processing</title>
        <meta name="description" content="Cosmo AI Assistant is an Outlook extension which helps to automate email processing, eg. creating offer requests for insurance agents." />
      </Head>
      <SignedIn>
        <p className="bg-red-400 p-8">You have successfully signed in</p>
      </SignedIn>
      <SignedOut>
        <p className="bg-red-400 p-8">
          Sign up for an account to get started <SignupLink />
        </p>
      </SignedOut>
      <main>
        <Hero />
        <PrimaryFeatures />
        <SecondaryFeatures />
        <CallToAction />
      </main>
    </>
  )
}